
import streamlit as st
import pandas as pd
import plotly.express as px

# ---------------- PAGE CONFIGURATION ----------------

st.set_page_config(
    page_title="PriceWise",
    page_icon="🛍️",
    layout="wide"
)

# ---------------- LOAD DATA ----------------

data = pd.read_csv("products.csv")

# ---------------- HEADER ----------------

st.title("🛍️ PriceWise")
st.subheader("Smart Product Price Comparison System")

st.write(
    "Compare prices across online stores, "
    "discover the best deals and shop smarter."
)

st.info(
    "Demo project: Product prices are sample data, "
    "not live store prices."
)

st.divider()

# ---------------- SIDEBAR FILTERS ----------------

st.sidebar.title("🔍 Find Your Product")

categories = ["All"] + sorted(data["Category"].unique())

category = st.sidebar.selectbox(
    "Select Category",
    categories
)

search = st.sidebar.text_input(
    "Search Product"
)

# Keep all store offers available for comparison.
filtered_data = data.copy()

if category != "All":
    filtered_data = filtered_data[
        filtered_data["Category"] == category
    ]

if search:
    filtered_data = filtered_data[
        filtered_data["Product"].str.contains(
            search,
            case=False,
            na=False
        )
    ]

# Budget filter
if len(filtered_data) > 0:

    min_price = int(filtered_data["Price"].min())
    max_price = int(filtered_data["Price"].max())

    if min_price < max_price:

        budget = st.sidebar.slider(
            "Maximum Budget (₹)",
            min_value=min_price,
            max_value=max_price,
            value=max_price,
            step=100
        )

        filtered_data = filtered_data[
            filtered_data["Price"] <= budget
        ]

# ---------------- OVERVIEW ----------------

st.header("📊 Shopping Overview")

col1, col2, col3 = st.columns(3)

with col1:
    st.metric(
        "Products Available",
        filtered_data["Product"].nunique()
    )

with col2:
    st.metric(
        "Total Store Offers",
        len(filtered_data)
    )

with col3:
    if len(filtered_data) > 0:
        st.metric(
            "Lowest Price",
            "₹{:,.0f}".format(filtered_data["Price"].min())
        )
    else:
        st.metric("Lowest Price", "N/A")

st.divider()

# ---------------- NAVIGATION TABS ----------------

tab1, tab2, tab3, tab4 = st.tabs([
    "🏠 Home",
    "🏷️ Price Comparison",
    "📈 Analytics",
    "📁 Dataset"
])

# ---------------- HOME TAB ----------------

with tab1:

    st.header("Welcome to PriceWise!")

    st.write(
        "PriceWise helps customers compare product prices "
        "from multiple online stores."
    )

    st.subheader("✨ Key Features")

    col1, col2 = st.columns(2)

    with col1:
        st.info("🔍 Search and filter products")
        st.info("💰 Find the lowest available price")

    with col2:
        st.info("📊 Interactive price charts")
        st.info("🏬 Compare multiple online stores")

    st.subheader("🏆 Best Available Deals")

    if len(filtered_data) > 0:

        best_deals = filtered_data.loc[
            filtered_data.groupby("Product")["Price"].idxmin()
        ]

        best_deals = best_deals.sort_values("Price")

        st.dataframe(
            best_deals[
                ["Product", "Store", "Price", "Rating"]
            ],
            use_container_width=True,
            hide_index=True
        )

    else:
        st.warning("No products found. Change your filters.")

# ---------------- PRICE COMPARISON TAB ----------------

with tab2:

    st.header("🏷️ Compare Product Prices")

    if len(filtered_data) == 0:

        st.warning("No products found. Change your filters.")

    else:

        products = sorted(filtered_data["Product"].unique())

        selected_product = st.selectbox(
            "Choose a Product",
            products
        )

        product_data = filtered_data[
            filtered_data["Product"] == selected_product
        ]

        product_data = product_data.sort_values("Price")

        best_offer = product_data.iloc[0]

        lowest_price = product_data["Price"].min()
        highest_price = product_data["Price"].max()

        savings = highest_price - lowest_price

        st.success(
            "🏆 Best Deal: {} at ₹{:,.0f}".format(
                best_offer["Store"],
                lowest_price
            )
        )

        col1, col2, col3 = st.columns(3)

        col1.metric(
            "Best Price",
            "₹{:,.0f}".format(lowest_price)
        )

        col2.metric(
            "Best Store",
            best_offer["Store"]
        )

        col3.metric(
            "Maximum Price Difference",
            "₹{:,.0f}".format(savings)
        )

        st.subheader("Available Store Offers")

        st.dataframe(
            product_data[
                ["Store", "Price", "Rating", "Delivery_Days"]
            ],
            use_container_width=True,
            hide_index=True
        )

        st.subheader("📊 Visual Price Comparison")

        fig = px.bar(
            product_data,
            x="Store",
            y="Price",
            color="Store",
            text="Price",
            title="Store-wise Product Price Comparison"
        )

        fig.update_layout(
            height=450,
            showlegend=False
        )

        st.plotly_chart(
            fig,
            use_container_width=True
        )

# ---------------- ANALYTICS TAB ----------------

with tab3:

    st.header("📈 Price Analytics")

    if len(filtered_data) == 0:

        st.warning("No data available for analysis.")

    else:

        st.subheader("Product Price Summary")

        summary = filtered_data.groupby("Product")["Price"].agg(
            ["min", "max", "mean"]
        ).reset_index()

        summary.columns = [
            "Product",
            "Lowest Price",
            "Highest Price",
            "Average Price"
        ]

        st.dataframe(
            summary,
            use_container_width=True,
            hide_index=True
        )

        st.subheader("Average Product Prices")

        fig1 = px.bar(
            summary,
            x="Product",
            y="Average Price",
            color="Product",
            title="Average Price of Each Product"
        )

        fig1.update_layout(
            height=450,
            showlegend=False
        )

        st.plotly_chart(
            fig1,
            use_container_width=True
        )

        st.subheader("Store-wise Average Prices")

        store_summary = filtered_data.groupby("Store")[
            "Price"
        ].mean().reset_index()

        fig2 = px.bar(
            store_summary,
            x="Store",
            y="Price",
            color="Store",
            title="Average Product Price by Store"
        )

        fig2.update_layout(height=400)

        st.plotly_chart(
            fig2,
            use_container_width=True
        )

        st.subheader("Category Distribution")

        category_summary = filtered_data.groupby(
            "Category"
        )["Product"].nunique().reset_index()

        fig3 = px.pie(
            category_summary,
            names="Category",
            values="Product",
            title="Products by Category"
        )

        fig3.update_traces(
            textinfo="percent+label"
        )

        st.plotly_chart(
            fig3,
            use_container_width=True
        )

# ---------------- DATASET TAB ----------------

with tab4:

    st.header("📁 Product Dataset")

    st.write("Explore the product information used in PriceWise.")

    if st.checkbox("Show Complete Dataset"):

        st.dataframe(
            data,
            use_container_width=True,
            hide_index=True
        )

    st.subheader("Descriptive Statistics")

    st.dataframe(
        filtered_data[
            ["Price", "Rating", "Delivery_Days"]
        ].describe(),
        use_container_width=True
    )

    st.write("Dataset Dimensions:", data.shape)

    st.write("Column Information:")

    st.write(data.dtypes)

# ---------------- FOOTER ----------------

st.divider()

st.caption(
    "PriceWise | Smart Product Price Comparison System"
)

st.caption(
    "Developed using Python, Streamlit, Pandas and Plotly"
)
